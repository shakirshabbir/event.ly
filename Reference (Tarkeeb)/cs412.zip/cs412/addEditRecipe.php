<?php
	require_once ('includes/classes/user.php');	
	if(!isset($_SESSION)) session_start();
	User::validateUser($_SESSION['username'], $user);
?>

<?php
	require_once ('includes/classes/region.php');
	require_once ('includes/classes/category.php');
	require_once ('includes/classes/recipe.php');
?>


<?php
	$recipeId = -1;
	
	if (isset($_GET['recipeId'])) {
		$recipeId = $_GET['recipeId'];
		$recipe = Recipe::getRecipeById($recipeId);
		
		if ($recipe == null)
		header( 'Location: error.php?errorMsg=' . urlencode("No Recipe found!") );
			
		
		if ( ($user!=null && $recipe->userId!=$user->id) && ($user->type != "admin") )
		header( 'Location: error.php?errorMsg=' . urlencode("You cannot edit another user's recipe!") );
	}
?>

<?php
	if ( isset($_POST['recipeAdd']) || isset($_POST['recipeUpdate']) ) {		
		$operationSuccessful = false;
		$imagesSequence = array();
		$imagesSequence[0] = ( isset($_FILES['image1']) && $_FILES['image1']['error'] == UPLOAD_ERR_OK )? true : false;
		$imagesSequence[1] = ( isset($_FILES['image2']) && $_FILES['image2']['error'] == UPLOAD_ERR_OK )? true : false;
		$imagesSequence[2] = ( isset($_FILES['image3']) && $_FILES['image3']['error'] == UPLOAD_ERR_OK )? true : false;
		$erroMsgs = array();
		$successfulUploads = array();
		$validExt = array("jpg", "png");
		$validMime = array("image/jpeg", "image/png");
		$i=0; $y=0;
		if (count($_FILES) > 0){
			foreach($_FILES as $fileKey => $fileArray) {
				$fileName = $fileArray["name"];
				if($fileArray["error"] == UPLOAD_ERR_OK) { // no error
					$value = explode(".", $fileName);
					$extension = strtolower(array_pop($value));
					//$extension = end(explode(".", $fileArray["name"])); //As defined in the powerpoint, but results in warning
					if ( in_array($fileArray["type"], $validMime) && in_array($extension, $validExt) ){ //Mime Type & Extension are valid
						$fileToMove = $fileArray["tmp_name"];
						$pathDefined = false;
						$path = "./upload/". $user->username;
						if ( is_dir($path) ) $pathDefined = true;
						if (!$pathDefined) $pathDefined = mkdir($path); // use @mkdir if you want to suppress warnings/errors
						if ($pathDefined) $destination = $path; else $destination = "./upload/";
						$destination .= "/" . $fileName;
						if (move_uploaded_file($fileToMove, $destination)){
							//while ($imagesSequence[$i] !== true && $i<3) $i++;
							$successfulUploads[$i++] = $destination;
							//echo "File: ". $fileName ." uploaded successfully!";
						}
						else
						$erroMsgs[$y++] = "File ". $fileName . " was not saved on the server computer.";
					}
					else
					$erroMsgs[$y++] = "File ". $fileName . " has not a valid PNG OR JPG extentsion.";
				}
				else
					$erroMsgs[$y++] = "File ". $fileName . " was not uploaded successfully.";
			}
		}
		
		if ( isset($_POST['recipeUpdate']) ) {
			$recipeId = $_POST['recipeId'];
			$recipe = Recipe::getRecipeById($recipeId);
		}
		else if ( isset($_POST['recipeAdd']) ) {
			$recipe = new Recipe();
		}
		
		if ($recipe!=null) {
			$recipe->categoryId = $_POST['categoryId'];
			$recipe->regionId = $_POST['regionId'];			
			$recipe->title = $_POST['title'];
			$recipe->subtitle = $_POST['subtitle'];
			$recipe->recipe = $_POST['recipe'];
			$recipe->imagealt1 = $_POST['imagealt1'];
			$recipe->imagealt2 = $_POST['imagealt2'];
			$recipe->imagealt3 = $_POST['imagealt3'];		
			
			if ( isset($_POST['recipeAdd']) ) {
				$recipe->userId = $user->id;
				$recipe->approval = 0;
				$recipe->featured = 0;
				$recipe->image1 = isset($successfulUploads[0]) ? $successfulUploads[0] : '';
				$recipe->image2 = isset($successfulUploads[1]) ? $successfulUploads[1] : '';
				$recipe->image3 = isset($successfulUploads[2]) ? $successfulUploads[2] : '';				
			}
			else if ( isset($_POST['recipeUpdate']) ) {
				$recipe->modified = date('Y-m-d G:i:s');
				
				$i=0;
				if ($imagesSequence[0] === true) {
					$recipe->image1 = isset($successfulUploads[$i]) ? $successfulUploads[$i] : '';
					$i++;
				}
				if ($imagesSequence[1] === true) {
					$recipe->image2 = isset($successfulUploads[$i]) ? $successfulUploads[$i] : '';
					$i++;
				}
				if ($imagesSequence[2] === true) {
					$recipe->image3 = isset($successfulUploads[$i]) ? $successfulUploads[$i] : '';
				}
			}
		}
		
		if ( isset($_POST['recipeAdd']) ) {
			if ( $recipe->addRecipe($lastInsertedId, $errorMessage) > 0) 		$operationSuccessful = true;
			else
				header( 'Location: error.php?errorMsg=' . urlencode($errorMessage. " ; "."Unable to save the recipe!") );
		}
		else if ( isset($_POST['recipeUpdate']) ) {
			if ( $recipe->updateRecipe() > 0) 	$operationSuccessful = true;
			else
				header( 'Location: error.php?errorMsg=' . urlencode("Unable to process the update of the recipe!") );
		}
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">

		 	<div class="bottom-grids">
				<div class="wrap">
					<?php
						if (isset($_POST['recipeAdd'])) {
							if (isset($lastInsertedId))
							echo ''. $operationSuccessful==true ? '<a>Insertion successful!</a> <a href="./recipePage.php?recipeId='.$lastInsertedId.'">Go to recipe</a>' : '<a>Insertion failed!</a>';
							else
							echo ''. $operationSuccessful==true ? '<a>Insertion successful!</a>' : '<a>Insertion failed!</a>';								
						}
						else if (isset($_POST['recipeUpdate'])) {
							echo ''. $operationSuccessful==true ? '<a>Update successful!</a> <a href="./recipePage.php?recipeId='.$_POST['recipeId'].'">Go to recipe</a>' : '<a>Update failed!</a>';
						}
					?>
					<div class="clear"> </div>
					<div class="form">
					    <form name="recipeForm" method="post" action="" enctype="multipart/form-data">
							<div>
								<span><label>Title</label></span>
						    	<input name="title" type="text" class="textbox" value="<?php echo "". ($recipeId == -1) ? "" : $recipe->title; ?>" required="required" />
						    </div>
						    <div>
						    	<span><label>Sub-title</label></span>
						    	<input name="subtitle" type="text" class="textbox" value ="<?php echo "". ($recipeId == -1) ? "" : $recipe->subtitle; ?>" required="required" />
						    </div>
						    <div>
						    	<span><label>Recipe</label></span>
						    	<textarea name="recipe" required="required"><?php echo "". ($recipeId == -1) ? "" : $recipe->recipe; ?></textarea>
						    </div>					
						    <div>
								<span><label>Category</label></span>
								<span><select name="categoryId">
								<?php
									$results = Category::getCategories(1);
									if (count($results) > 0){
										foreach($results as $row) {
										   echo '<option value="'.$row['id'].'"';
										   echo ''. ($recipeId != -1) && ($recipe->categoryId == $row['id']) ? 'selected="selected"' : '';
										   echo ' >';
										   echo $row['name'];
										   echo '</option>';
										}
									}
									else{
										echo '<option value="0">'.'No Defined Categories'.'</option>';
									}
								?>
								</select>
								</span>
						    </div>
						    <div>
						    	<span><label>Region</label></span>
						    	<span><select name="regionId">
								<?php
									$results = Region::getRegions(1);
									if (count($results) > 0){
										foreach($results as $row) {
										   echo '<option value="'.$row['id'].'"';
										   echo ''. ($recipeId != -1) && ($recipe->regionId == $row['id']) ? 'selected="selected"' : '';
										   echo ' >';
										   echo $row['name'];
										   echo '</option>';
										}
									}
									else{
										echo '<option value="0">'.'No Defined Regions'.'</option>';
									}
								?>
								</select>
								</span>
						    </div>							
							<div class="specials-grids">
								<div class="imagesS-grid">
									<?php echo ''. ($recipeId == -1) || ($recipe->image1=='') ? '<h1>Select Image 1</h1>' : '<img src="'.$recipe->image1.'" title="'.$recipe->imagealt1.'">'; ?>
									<input name="image1" type="file" />
									<input name="imagealt1" type="text" value="<?php echo "". ($recipeId == -1) ? "" : $recipe->imagealt1; ?>"/>
								</div>
								<div class="imagesS-grid">
									<?php echo ''. ($recipeId == -1) || ($recipe->image2=='') ? '<h1>Select Image 2</h1>' : '<img src="'.$recipe->image2.'" title="'.$recipe->imagealt2.'">'; ?>
									<input name="image2" type="file" />
									<input name="imagealt2" type="text" value ="<?php echo "". ($recipeId == -1) ? "" : $recipe->imagealt2; ?>" />
								</div>
								<div class="imagesS-grid spe-grid">
									<?php echo ''. ($recipeId == -1) || ($recipe->image3=='') ? '<h1>Select Image 2</h1>' : '<img src="'.$recipe->image3.'" title="'.$recipe->imagealt3.'">'; ?>							
									<input name="image3" type="file" />
									<input name="imagealt3" type="text" value="<?php echo "". ($recipeId == -1) ? "" : $recipe->imagealt3; ?>" />
								</div>
							</div>		
							<div class="clear"> </div>					
							<?php
								if ($recipeId == -1) echo '<span><input name="recipeAdd" type="submit" class="mybutton" value="Submit" /></span>';
								else {
									echo '<input name="recipeId" type="hidden" value="'.$recipeId.'" /></span>';
									echo '<span><input name="recipeUpdate" type="submit" class="mybutton" value="Update" /></span>';
								}
							?>
					    </form>
					</div>
					<div class="clear"> </div>
				</div><!-- end --><!-- class="wrap" -->
			</div>

		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>