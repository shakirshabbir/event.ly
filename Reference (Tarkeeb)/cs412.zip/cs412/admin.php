<?php
	require_once ('includes/classes/user.php');	
	if(!isset($_SESSION)) session_start();
	User::validateUser($_SESSION['username'], $user);
	
	if ($user!=null && $user->type!="admin")
	header( 'Location: error.php?errorMsg=' . urlencode("You cannot enter the Admin area because you are not an admin user!") );
?>

<?php
	require_once ('includes/classes/region.php');
	require_once ('includes/classes/category.php');
?>

<?php
	if ( isset($_POST['submitRegion']) )
	{
		$name = $_POST['regionName'];
		$desc = $_POST['regionDesc'];
		
		$region = new Region($name, $desc, 1);
		$region->addRegion();
	}
	
	if ( isset($_POST['submitCategory']) )
	{
		$name = $_POST['categoryName'];
		$desc = $_POST['categoryDesc'];
		
		$category = new Category($name, $desc, 1);
		$category->addCategory();
	}	
?>


<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>

		<script type="text/javascript">
			function moreRegions(){
				var divBox = document.getElementById('addRegionForm');
				divBox.style.display="block";
			}
			function moreCategories(){
				var divBox = document.getElementById('addCategoryForm');
				divBox.style.display="block";
			}	
		</script>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
			<div class="wrap" id="addCategoryForm" style="display:none">
				<div class="form">
					<a class="button">Add a Category</a>
					<form method="post" action="admin.php">					    	
						<span><label>Name</label></span>
						<input name="categoryName" required="required" type="text" class="textbox">						    

						<span><label>Description</label></span>
						<span><input name="categoryDesc" type="text" class="textbox"></span>

						<span><input name="submitCategory" type="submit" class="mybutton" value="Submit"></span>
					</form>
				</div>
				<div class="clear"> </div>
			</div>		

			<div class="wrap" id="addRegionForm" style="display:none">
				<div class="form">
					<a class="button" href="gallery.html">Add a Region</a>
					<form method="post" action="admin.php">
						<span><label>Name</label></span>
						<input name="regionName" required="required" type="text" class="textbox">

						<span><label>Description</label></span>
						<span><input name="regionDesc" type="text" class="textbox"></span>

						<span><input name="submitRegion" type="submit" class="mybutton" value="Submit"></span>
					</form>
				</div>
				<div class="clear"> </div>
			</div>			
					
			<div class="wrap">
				<a href="adminApproval.php" class="button" style="float:right;">Approvals</a>
				<a href="adminFeatured.php" class="button" style="float:right;">Featured</a>
			</div>			
			
		 	<div class="bottom-grids">
				<div class="wrap">
					<div class="bottom-grid1">
						<h3>Categories</h3>
						<ul>
							<?php
								$results = Category::getCategories(1);
								if (count($results) > 0){
									foreach($results as $row) {
									   echo '<li><a><span>'.$row['name'].'</span></a></li>';
									}
								}
								else{
									echo '<li><a><span>'.'No Categories!'.'</span></a></li>';
								}
							?>
						</ul>
						<a id="moreCategories" onclick="moreCategories()" class="button" href="#">+</a>
					</div>
					<div class="bottom-grid1">
						<h3>Regions</h3>
						<ul>
							<?php
								$results = Region::getRegions(1);
								if (count($results) > 0){
									foreach($results as $row) {
									   echo '<li><a><span>'.$row['name'].'</span></a></li>';
									}
								}
								else{
									echo '<li><a><span>'.'No Regions!'.'</span></a></li>';
								}
							?>
						</ul>
						<a id="moreRegions" onclick="moreRegions()" class="button" href="#">+</a>
					</div>

					<div class="clear"> </div>
				</div><!-- end --><!-- class="wrap" -->
				<div class="clear"> </div>
			</div>

			</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>