<?php
	require_once ('includes/classes/user.php');	
	if(!isset($_SESSION)) session_start();
	User::validateUser($_SESSION['username'], $user);
	
	if ($user!=null && $user->type!="admin")
	header( 'Location: error.php?errorMsg=' . urlencode("You cannot enter the Admin area because you are not an admin user!") );
?>

<?php
	require_once ('includes/classes/recipe.php');
	$results = Recipe::getAllRecipes();
?>

<?php
	if ( isset($_POST['approvalSubmit']) ) {
		$success = false;
		$approvals = array();
		if (isset($_POST['approval']))
		$approvals = $_POST['approval'];
		$unApprovals = array();
		
		$allRecipes = array(); $i=0;
		foreach ($results as $row){
			if (!in_array($row['id'], $approvals))
				$unApprovals[$i++] = $row['id'];
		}
		foreach($approvals as $approval) {
			$recipe = Recipe::getRecipeById($approval);
			if ($recipe!=null && $recipe->approval==0){
				$recipe->approval = 1;
				$recipe->modified = date('Y-m-d G:i:s');
				if ( $recipe->updateRecipe() > 0) $updateSuccessful=true;
				else
				header( 'Location: error.php?errorMsg=' . urlencode("Unable to process the approvals!") );				
			}
		}
		foreach($unApprovals as $unApproval) {
			$recipe = Recipe::getRecipeById($unApproval);
			if ($recipe!=null  && $recipe->approval==1){
				$recipe->approval = 0;
				$recipe->modified = date('Y-m-d G:i:s');
				if ( $recipe->updateRecipe() > 0) $updateSuccessful=true;
				else
				header( 'Location: error.php?errorMsg=' . urlencode("Unable to process the approvals!") );				
			}
		}
		$success = true;		
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<script type="text/javascript">
		function albuwi(obj){
			var checkboxes = document.getElementsByName("approval[]");
			var length = checkboxes.length;
			for (var i=0; i<length; i++) {
				checkboxes[i].checked = obj.checked;
			}	
		}
	</script>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
		 	<div class="bottom-grids">
				<div class="wrap">
					<div class="about-header">
						<h3 style="display:inline;">Admin Approvals</h3>&nbsp;&nbsp;&nbsp;
						<span>* checked boxes corresponds to approved recipes & vice-versa for unchecked</span><br /><div class="clear"></div>
					</div>				
					<?php
						if (isset($success) && $success==true) echo '<h1 style="color:green;"><strong>Changes have been updated!</strong></h1>';
					?>
					<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<div class="adminTable">
						<table>
							<tr>
								<td>
									<input type="checkbox" name="selectAll" id="selectAll" style="float:left;" onclick="albuwi(this);" />Approval
								</td>
								<td >
									Recipe-Title
								</td>
								<td>
									Recipe-Subtitle
								</td>
								<td>
									Last Modified
								</td>									
								<td>
									Submitted by
								</td>								
							</tr>
							<?php
								$results = Recipe::getAllRecipes();
								if (count($results) > 0){
									foreach($results as $row) {
										echo '<tr>';
										echo '<td><input type="checkbox" name="approval[]" id="approval" value="'.$row['id'].'"';
										if ($row['approval']==1) echo ' checked="checked" ';
										echo ' />';
										echo '<td>'.$row['title'].'</td>';
										echo '<td>'.$row['subtitle'].'</td>';
										echo '<td>'.$row['modified'].'</td>';
										$user = User::getUserByUserId($row['userId']);
										if ($user!=null) echo '<td>'.$user->username.'</td>';
										else echo '<td>'.'Error fetching username!'.'</td>';
										echo '</tr>';
									}
								}
								/*
								else{
									echo '<li><a><span>'.'No Regions!'.'</span></a></li>';
								}*/								
							?>
						</table>
					</div>
					<br />
					<span><input name="approvalSubmit" type="submit" class="mybutton" value="Submit"></span>
					</form>
				</div><!-- end --><!-- class="wrap" -->
			</div>
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>