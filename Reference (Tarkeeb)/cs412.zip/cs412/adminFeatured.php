<?php
	require_once ('includes/classes/user.php');	
	if(!isset($_SESSION)) session_start();
	User::validateUser($_SESSION['username'], $user);
	
	if ($user!=null && $user->type!="admin")
	header( 'Location: error.php?errorMsg=' . urlencode("You cannot enter the Admin area because you are not an admin user!") );
?>

<?php
	require_once ('includes/classes/recipe.php');
	$results = Recipe::getAllRecipes();
?>

<?php
	if ( isset($_POST['featuredSubmit']) ) {
		$success = false;
		$featured = array();
		if (isset($_POST['featured']))
		$featured = $_POST['featured'];
		$unFeatured = array();
		
		$allRecipes = array(); $i=0;
		foreach ($results as $row){
			if (!in_array($row['id'], $featured))
				$unFeatured[$i++] = $row['id'];
		}
		foreach($featured as $feature) {
			$recipe = Recipe::getRecipeById($feature);
			if ($recipe!=null && $recipe->featured==0){
				$recipe->featured = 1;
				$recipe->modified = date('Y-m-d G:i:s');
				if ( $recipe->updateRecipe() > 0) $updateSuccessful=true;
				else
				header( 'Location: error.php?errorMsg=' . urlencode("Unable to process the featureds!") );				
			}
		}
		foreach($unFeatured as $unFeature) {
			$recipe = Recipe::getRecipeById($unFeature);
			if ($recipe!=null  && $recipe->featured==1){
				$recipe->featured = 0;
				$recipe->modified = date('Y-m-d G:i:s');
				if ( $recipe->updateRecipe() > 0) $updateSuccessful=true;
				else
				header( 'Location: error.php?errorMsg=' . urlencode("Unable to process the featureds!") );				
			}
		}
		$success = true;		
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<script type="text/javascript">
		function albuwi(obj){
			var checkboxes = document.getElementsByName("featured[]");
			var length = checkboxes.length;
			for (var i=0; i<length; i++) {
				checkboxes[i].checked = obj.checked;
			}	
		}
	</script>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
		 	<div class="bottom-grids">
				<div class="wrap">
					<div class="about-header">
						<h3 style="display:inline;">Admin Featured Recipes</h3>&nbsp;&nbsp;&nbsp;
						<span>* checked boxes corresponds to featured recipes & vice-versa for unchecked</span><br /><div class="clear"></div>
					</div>				
					<?php
						if (isset($success) && $success==true) echo '<h1 style="color:green;"><strong>Changes have been updated!</strong></h1>';
					?>
					<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<div class="adminTable">
						<table>
							<tr>
								<td>
									<input type="checkbox" name="selectAll" id="selectAll" style="float:left;" onclick="albuwi(this);" />Featured
								</td>
								<td >
									Recipe-Title
								</td>
								<td>
									Recipe-Subtitle
								</td>
								<td>
									Last Modified
								</td>									
								<td>
									Submitted by
								</td>								
							</tr>
							<?php
								$results = Recipe::getAllRecipes();
								if (count($results) > 0){
									foreach($results as $row) {
										echo '<tr>';
										echo '<td><input type="checkbox" name="featured[]" id="featured" value="'.$row['id'].'"';
										if ($row['featured']==1) echo ' checked="checked" ';
										echo ' />';
										echo '<td>'.$row['title'].'</td>';
										echo '<td>'.$row['subtitle'].'</td>';
										echo '<td>'.$row['modified'].'</td>';
										$user = User::getUserByUserId($row['userId']);
										if ($user!=null) echo '<td>'.$user->username.'</td>';
										else echo '<td>'.'Error fetching username!'.'</td>';
										echo '</tr>';
									}
								}
								/*
								else{
									echo '<li><a><span>'.'No Regions!'.'</span></a></li>';
								}*/								
							?>
						</table>
					</div>
					<br />
					<span><input name="featuredSubmit" type="submit" class="mybutton" value="Submit"></span>
					</form>
				</div><!-- end --><!-- class="wrap" -->
			</div>
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>