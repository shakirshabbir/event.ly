<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
		
			<div class="mid-grid">
				<div class="wrap">
					<h1>Oops! An error has occured while execution!</h1>
					<h2><?php if (isset($_GET['errorMsg'])) echo $_GET['errorMsg']; else echo "We are sorry for the inconvenience!"; ?></h2>
					<p>" Please report to the site admin as soon as possible. Thank you!"</p>
				</div><!-- end --><!-- class="wrap" -->
			</div>

		 	<div class="bottom-grids">
				<div class="wrap">
					<?php	require_once('./includes/latest.php');	?>
					<?php	require_once('./includes/featured.php');		?>
				</div><!-- end --><!-- class="wrap" -->
				<div class="clear"> </div>
			</div>
			
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>