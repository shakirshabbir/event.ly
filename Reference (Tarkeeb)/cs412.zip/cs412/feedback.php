<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
		 	<div class="bottom-grids">
				<div class="wrap">
					<div class="form">
					<form name="feedbackForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">							
						<span><label>Name</label></span>
						<input name="name" type="text" class="textbox" required="required" />

						<span><label>Email</label></span>
						<input name="email" type="email" class="textbox" required="required" />

						<span><label>Feedback</label></span>
						<textarea name="feedback" required="required"></textarea>
						<div class="clear"> </div>					

						<span><input name="feedbackSumbit" type="submit" class="mybutton" value="Submit" /></span>					
							
					</form>
					</div><!-- end --><!-- class="form" -->
				</div><!-- end --><!-- class="wrap" -->
			</div>
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>