<?php

require_once ('./includes/config.php');

class Category{
	
	public $id;
	public $name;
	public $description;
	public $parentId;
	
	public function __construct($name='', $description='', $parentId=0){
		$this->name = $name;
		$this->description = $description;
		$this->parentId = $parentId;
	}
	
	public function addCategory(){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->exec('INSERT INTO categories(name,description,parentId) VALUES("'.$this->name.'","'.$this->desc.'",1)');
		if($query>0)
			header('Location: admin.php');
		else
			header('Location: error.php?errorMsg='. urlencode($db->errorInfo()[2]));
	}

	public static function getCategories($parentId=1){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM categories WHERE parentId='. $parentId);
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}
	
	public static function getCategoryById($categoryId=1){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM categories WHERE id='. $categoryId);
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		if (count($results) > 0){
			$row = $results[0];
			$category = new Category();
	
			$category->id = $row['id'];
			$category->name = $row['name'];
			$category->description = $row['description'];
			$category->parentId = $row['parentId'];
			
			return $category;
		}
		else
			return null;
	}		
}

?>