<?php

require_once ('./includes/config.php');

class Recipe{
	
	public $id;
	public $categoryId;
	public $regionId;
	public $userId;
	public $approval;
	public $featured;	
	public $created;		
	public $modified;			
	
	public $title;
	public $subtitle;
	public $recipe;	
	public $image1;		
	public $image2;	
	public $image3;	
	public $imagealt1;		
	public $imagealt2;	
	public $imagealt3;		
	
	public function __construct(){
		$this->created = date('Y-m-d G:i:s');
		$this->modified = date('Y-m-d G:i:s');
	}
	
	public function addRecipe(&$lastInsertedId, &$errorMessage){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$string = "INSERT INTO recipes(categoryId, regionId, userId, approval, featured, created, modified, title, subtitle, recipe, image1, image2, image3, imagealt1, imagealt2, imagealt3)";
		$string.= "VALUES(";
		$string.= $this->categoryId . ",";
		$string.= $this->regionId . ",";		
		$string.= $this->userId . ",";
		$string.= $this->approval . ",";			
		$string.= $this->featured . ",";	
		$string.= "'". $this->created . "',";	
		$string.= "'". $this->modified . "',";	
		$string.= "'". addslashes($this->title) . "',";	
		$string.= "'". addslashes($this->subtitle) . "',";	
		$string.= "'". addslashes($this->recipe) . "',";	
		$string.= "'". $this->image1 . "',";	
		$string.= "'". $this->image2 . "',";	
		$string.= "'". $this->image3 . "',";	
		$string.= "'". addslashes($this->imagealt1) . "',";	
		$string.= "'". addslashes($this->imagealt2) . "',";	
		$string.= "'". addslashes($this->imagealt3) . "'";
		$string.= ")";		
		
		$query = $db->exec($string);
		if($query>0){
			$lastInsertedId = $db->lastInsertId();
			$errorMessage = $db->errorInfo()[2];
			return $query;
		}
		else
			header('Location: error.php?errorMsg='. urlencode($db->errorInfo()[2]));
			
		return -1;
	}

	public static function getRecipeByCategory($categoryId=0){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		if ($categoryId!=0)
		$query = $db->query('SELECT * FROM recipes WHERE approval=1 AND categoryId='. $categoryId);
		else
		$query = $db->query('SELECT * FROM recipes WHERE approval=1');
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}	
	
	public static function getRecipeByRegion($regionId=0){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		if ($regionId!=0)
		$query = $db->query('SELECT * FROM recipes WHERE approval=1 AND regionId='. $regionId);
		else
		$query = $db->query('SELECT * FROM recipes WHERE approval=1');
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}	
	
	public static function getFeaturedRecipes(){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM recipes WHERE approval=1 AND featured=1 ORDER BY created DESC LIMIT 6');
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}		
	
	public static function getLatestRecipes(){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM recipes WHERE approval=1 ORDER BY created DESC LIMIT 10');
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}		
	
	public static function getRecipesByUserId($userId){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM recipes WHERE userId='. $userId);
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}		
	
	public static function getRecipeById($recipeId=1){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM recipes WHERE id='. $recipeId);
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
	
		if (count($results) > 0){
			$row = $results[0];
			$recipe = new Recipe();
			
			$recipe->id = $row['id'];
			$recipe->categoryId = $row['categoryId'];
			$recipe->regionId = $row['regionId'];
			$recipe->userId = $row['userId'];
			$recipe->approval = $row['approval'];
			$recipe->featured = $row['featured'];
			$recipe->created = $row['created'];
			$recipe->modified = $row['modified'];
			$recipe->title = $row['title'];
			$recipe->subtitle = $row['subtitle'];
			$recipe->recipe = $row['recipe'];
			$recipe->image1 = $row['image1'];
			$recipe->image2 = $row['image2'];
			$recipe->image3 = $row['image3'];
			$recipe->imagealt1 = $row['imagealt1'];
			$recipe->imagealt2 = $row['imagealt2'];
			$recipe->imagealt3 = $row['imagealt3'];
			
			return $recipe;
		}
		else
			return null;
	}		
	
	public static function getAllRecipes(){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM recipes');
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		return $results;
	}			
	
	public function updateRecipe(){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$string = "UPDATE recipes SET ";
		$string.= "categoryId = " .$this->categoryId .", ";
		$string.= "regionId = " .$this->regionId .", ";		
		$string.= "userId = " .$this->userId .", ";		
		$string.= "approval = " .$this->approval .", ";						
		$string.= "featured = " .$this->featured .", ";						
		$string.= "created = '" .$this->created ."', ";			
		$string.= "modified = '" .$this->modified ."', ";				
		$string.= "title = '" .addslashes($this->title) ."', ";				
		$string.= "subtitle = '" . addslashes($this->subtitle)."', ";				
		$string.= "recipe = '" .addslashes($this->recipe) ."', ";		
		$string.= "image1 = '" .$this->image1 ."', ";		
		$string.= "image2 = '" .$this->image2 ."', ";		
		$string.= "image3 = '" .$this->image3 ."', ";		
		$string.= "imagealt1 = '" .addslashes($this->imagealt1) ."', ";		
		$string.= "imagealt2 = '" .addslashes($this->imagealt2) ."', ";		
		$string.= "imagealt3 = '" .addslashes($this->imagealt3) ."' ";		
		$string.= "WHERE id = ". $this->id;		
		
		$query = $db->exec($string);
		if($query>0)
			return $query;
		else
			header('Location: error.php?errorMsg='. urlencode($db->errorInfo()[2]));
			
		return -1;		
	}		
}

?>