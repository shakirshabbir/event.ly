<?php

require_once ('./includes/config.php');

class Region{
	
	public $id;
	public $name;
	public $description;
	public $parentId;
	
	public function __construct($name='', $description='', $parentId=0){
		$this->name = $name;
		$this->description = $description;
		$this->parentId = $parentId;
	}
	
	public function addRegion(){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->exec('INSERT INTO regions(name,description,parentId) VALUES("'.$this->name.'","'.$this->desc.'",1)');
		if($query>0)
			header('Location: admin.php');
		else
			header('Location: error.php?errorMsg='. urlencode($db->errorInfo()[2]));
	}

	public static function getRegions($parentId=1){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM regions WHERE parentId='. $parentId);
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}
	
	public static function getRegionById($regionId=1){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM regions WHERE id='. $regionId);
		$results = $query->fetchAll(PDO::FETCH_ASSOC);
		
		if (count($results) > 0){
			$row = $results[0];
			$region = new Region();
	
			$region->id = $row['id'];
			$region->name = $row['name'];
			$region->description = $row['description'];
			$region->parentId = $row['parentId'];
			
			return $region;
		}
		else
			return null;
	}			
}

?>