<?php

require_once ('./includes/config.php');

class User{
	
	public $id;
	public $username;
	public $password;
	public $type;
	
	public function __construct($userName='', $password=''){
		$this->username = $userName;
		$this->password = $password;
	}
	
	public function authenticate(){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM users WHERE username="'.$this->username.'" AND password="'.$this->password.'"');
		$results = $query->fetch(PDO::FETCH_ASSOC);
        if ($query->rowCount() > 0){
			return true;
        }
        else{
			return false;
		}
	}
	
	public static function getUserByUserName($username){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM users WHERE username="'. $username. '"');
		$results = $query->fetchAll(PDO::FETCH_ASSOC);		
		
		if (count($results) > 0){
			$row = $results[0];
			$user = new User();
			
			$user->id = $row['id'];
			$user->username = $row['username'];
			$user->password = $row['password'];
			$user->type = $row['type'];		
			
			return $user;
		}
		else
			return null;		
	}
	
	public static function getUserByUserId($userId){
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$query = $db->query('SELECT * FROM users WHERE id='. $userId);
		$results = $query->fetchAll(PDO::FETCH_ASSOC);		
		
		if (count($results) > 0){
			$row = $results[0];
			$user = new User();
			
			$user->id = $row['id'];
			$user->username = $row['username'];
			$user->password = $row['password'];
			$user->type = $row['type'];		
			
			return $user;
		}
		else
			return null;		
	}	
	
	public static function validateUser($username, &$user){
		$user = User::getUserByUserName($username);
		if ($user!=null)
			return true;
		else
			header( 'Location: error.php?errorMsg=' . urlencode("You tried to enter a restricted area!") );
		
		return false;
	}
	
	public function createNewUser($username, $password, $email, &$user){
		$this->username = $username;
		$this->password = $password;
		$this->type = "user";
		
		$db = new PDO('mysql:host='.DBHOST.';dbname='.DB.'', DBUSER, DBPASSWORD);
		$string = "INSERT INTO users(username, password, type) ";
		$string.= "VALUES(";
		$string.= "'". $this->username . "',";
		$string.= "'". $this->password . "',";		
		$string.= "'". $this->type . "'";
		$string.= ")";

		$query = $db->exec($string);
		if($query>0){
			$user = User::getUserByUserName($username);
			if ($user!=null)
				return true;
			else
				header( 'Location: error.php?errorMsg=' . urlencode("Unable to register this user!") );
		}
		else
			header('Location: error.php?errorMsg='. urlencode($db->errorInfo()[2]));

		return false;
	}	
}

?>