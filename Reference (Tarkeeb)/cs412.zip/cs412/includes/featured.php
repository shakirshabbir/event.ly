<!-- featured.php -->
<?php
	require_once ('includes/classes/recipe.php');
?>

<div class="bottom-grid2 bottom-mid grid-recipes">
	<h3>FEATURED RECIPES</h3>
	<span>We have featured the best recipes for you that you might want to give a definite try!</span>
	<p>Featured from different categories & regions to satisfy your love for the food!</p>
	<div class="gallery">
	<?php
		$results = Recipe::getFeaturedRecipes();
		if (count($results) > 0){
			echo '<ul>';
			foreach($results as $row) {
				echo '<li><a href="./recipePage.php?recipeId='.$row['id'].'"><img src="'.$row['image1'].'" title="'.$row['title'].'" /></a></li>';
			}
			echo '</ul>';			
		}				
	?>										
	<div class="clear"> </div>
	</div>
</div>