<!-- footer.php -->
<div class="footer">
	<p>A group project for CS-412 by | SHAKIR SHABBIR | AZAM MOHAMMAD | IMRAN KHAN |</p>
</div>