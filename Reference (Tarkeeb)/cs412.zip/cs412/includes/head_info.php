<!-- head_info.php -->

<title>Tarkeeb - Food with love</title>
<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />