<!-- latest.php -->
<?php
	require_once ('includes/classes/recipe.php');
?>

<div class="bottom-grid1">
	<h3>LATEST RECIPES</h3>
	<span>These recipes were recently posted by our users</span>
	<p></p>
	<?php
		$results = Recipe::getLatestRecipes();
		if (count($results) > 0){
			echo '<ul>';
			foreach($results as $row) {
				echo '<li><a href="./recipePage.php?recipeId='.$row['id'].'">'.$row['title'].'</a></li>';
			}
			echo '</ul>';			
		}				
	?>
</div>