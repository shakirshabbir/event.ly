<!-- top_header.php -->
<div class="top-header">
	<div class="logo">
		<a href="index.php"><img src="images/logo.png" title="logo" /></a>
	</div>
	<div class="clear"> </div>
</div>