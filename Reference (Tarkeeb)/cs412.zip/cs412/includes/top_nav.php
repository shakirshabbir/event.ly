<!-- top_nav.php -->
<?php
	require_once ('includes/classes/user.php');	
	if(!isset($_SESSION)) session_start();
	if ( isset($_SESSION['loggedin']) && $_SESSION['loggedin'] ){
		$user = User::getUserByUserName($_SESSION['username']);
		$loggedIn = true;
	}
	else
		$loggedIn = false;	
?>

<div class="top-nav">
	<div class="top-nav-left">
		<ul>
			<li><a href="./index.php">Home</a></li>
			<li><a href="./recipePage.php?recipeId=17">About Us</a></li>
			<li><a href="./feedback.php">Feedback</a></li>
			<?php
				if (!$loggedIn){
					echo '<li><a href="./login.php">Login</a></li>';
				}
				else {
					if ($user!=null && $user->type=="admin") {
						echo '<li><a href="admin.php">Admin Dashborad</a></li>';
					}
					echo '<li><a href="userDashboard.php">User Dashboard</a></li>';
				}
			?>
			<div class="clear"> </div>
		</ul>
	</div>

	<div class="clear"> </div>
</div>