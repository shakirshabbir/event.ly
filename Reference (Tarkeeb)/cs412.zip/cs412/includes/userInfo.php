<!-- userInfo.php -->
<?php
	if(!isset($_SESSION)) session_start();
	
	/* If user is logged in, display a status bar */
	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		echo '<div class="userInfo">';
		echo 'Welcome, <a href="userDashboard.php">'. $_SESSION['username']. '</a>';
		echo '</div>';
	}
?>