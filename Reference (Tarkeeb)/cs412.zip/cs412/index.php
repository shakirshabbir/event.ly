<?php
	require_once ('./includes/classes/region.php');
	require_once ('./includes/classes/category.php');
	require_once ('./includes/classes/recipe.php');
?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->

		<!-- Content -->
		<div class="content">
			<div class="mid-grid">
				<div class="wrap">
			 		<h1>Welcome to our site <br /> TARKEEB - food with Love!</h1>
			 		<h2>We have a wide range of recipes organized under different categories & regions</h2>
			 		<p>"From the Turkish delights to Meditarrian foods, we have a bunch of panel & user submitted recipes to please your taste buds!"</p>
			 		<a class="button1" href="./recipePage.php?recipeId=17">Read more about us</a>
		 		</div><!-- end --><!-- class="wrap" -->
		 	</div>
			
			<div class="top-grids">
				<div class="wrap">
					<!-- Recipes-Categories -->
					<div class="top-grid">
						<a href="recipeCategories.php"><img src="images/foodieIcon.png" title="icon-name"></a>
						<h3>Recipes by Categories</h3>
						<?php 
							$results = Category::getCategories();
							$categories = array();
							$categories[0] = array($results[0]['id'], $results[0]['name']);
							$categories[1] = array($results[1]['id'], $results[1]['name']);
							$categories[2] = array($results[2]['id'], $results[2]['name']);
						?>
						<p>
						We have a collection of favourite recipes in various categories such as 
						<?php
							echo '<a href="./recipeCategories.php?categoryId='.$categories[0][0].'" style="color:inherit;">'.$categories[0][1].'</a>'.', ';
							echo '<a href="./recipeCategories.php?categoryId='.$categories[1][0].'" style="color:inherit;">'.$categories[1][1].'</a>'.', ';
							echo '<a href="./recipeCategories.php?categoryId='.$categories[2][0].'" style="color:inherit;">'.$categories[2][1].'</a>';
						?>
						</p>
						<a class="button" href="recipeCategories.php">Browse</a>
					</div>
					<!-- end --><!-- Recipes-Categories -->
					
					<!-- Recipes-Region -->
					<div class="top-grid">
						<a href="recipeRegions.php"><img src="images/foodieIcon.png" title="icon-name"></a>
						<h3>Recipes by Region</h3>
						<?php 
							$results = Region::getRegions();
							$regions = array();
							$regions[0] = array($results[0]['id'], $results[0]['name']);
							$regions[1] = array($results[1]['id'], $results[1]['name']);
							$regions[2] = array($results[2]['id'], $results[2]['name']);
						?>						
						<p>
						Enjoy our collection of diversified recipes from the regions of
						<?php
							echo '<a href="./recipeRegions.php?regionId='.$regions[0][0].'" style="color:inherit;">'.$regions[0][1].'</a>'.', ';
							echo '<a href="./recipeRegions.php?regionId='.$regions[1][0].'" style="color:inherit;">'.$regions[1][1].'</a>'.', ';
							echo '<a href="./recipeRegions.php?regionId='.$regions[2][0].'" style="color:inherit;">'.$regions[2][1].'</a>';
						?>						
						</p>
						<a class="button" href="recipeRegions.php">Browse</a>
					</div>
					<!-- end --><!-- Recipes-Region -->
					
					<!-- Contribute -->
					<div class="top-grid last-topgrid">
						<a><img src="images/foodieIcon.png" title="icon-name"></a>
						<h3>Contribute</h3>
						<p>To post a recipe of your own, you need to register as a member</p>
						<a class="button" href="register.php">Register</a><a class="button" href="login.php">Login</a>
					</div>
					<!-- end --><!-- Contribute -->
		 		</div><!-- end --><!-- class="wrap" -->
		 	</div>

		 	<div class="bottom-grids">
				<div class="wrap">
					<?php	require_once('./includes/latest.php');	?>
					<?php	require_once('./includes/featured.php');		?>
				</div><!-- end --><!-- class="wrap" -->
				<div class="clear"> </div>
			</div>
			
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>