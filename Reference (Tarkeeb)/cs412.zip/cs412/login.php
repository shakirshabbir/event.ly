<?php
	require_once ('includes/classes/user.php');
?>

<?php
	if ( isset($_POST['submitLogin']) )
	{
		$username = $_POST['userName'];
		$password = $_POST['password'];
		
		$user = new User($username, $password);
		$isValidUser = $user->authenticate();
		
		if ($isValidUser) {
			session_start();
			$_SESSION['loggedin'] = true;
			$_SESSION['username'] = $username;
			$_SESSION['startTime'] = time();
			
			header( 'Location: index.php' );
		}
		else
			echo "<script> alert('You have entered wrong credentials!') </script>";
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
		
			<div class="mid-grid">
				<div class="wrap">
					<?php
						//if ($errorMessage!="")
							//echo "<h3>".$errorMessage."</h3><br/>";
					?>
					<div class="login">
						<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
							<div>
								<label>Username</label>&nbsp;&nbsp;&nbsp;
								<input name="userName" type="text" class="textbox" required="required" />
							</div><br />
							<div>
								<label>Password</label>&nbsp;&nbsp;&nbsp;
								<input name="password" type="password" class="textbox" required="required" />
							</div><br />						   
							<span><input name="submitLogin" type="submit" class="mybutton" value="Submit"></span>
						</form>
					</div><!-- end --><!-- id="login" -->
				</div><!-- end --><!-- class="wrap" -->
			</div>

		 	<div class="bottom-grids">
				<div class="wrap">
					<?php	require_once('./includes/latest.php');	?>
					<?php	require_once('./includes/featured.php');		?>
				</div> <!-- end --><!-- Wrap -->
				<div class="clear"> </div>
			</div>
			
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>