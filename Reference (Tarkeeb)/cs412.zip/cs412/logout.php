<?php
	require_once ('includes/classes/user.php');	
	
	if(!isset($_SESSION)) session_start();
	if (!$_SESSION['loggedin'])
	header( 'Location: index.php' );
	
	$username = $_SESSION['username'];
	$startTime = $_SESSION['startTime'];
	
	session_unset();

	session_destroy(); 	
	$duration = time() - $startTime;
?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">

			<div class="mid-grid">
				<div class="wrap">
					<h1>Dear <?php echo $username; ?>, you have successfully been logged out!</h1>
					<h2>Thank you for exploring our website! Hope you liked it. We would appreciate your valuable feedback.</h2>
					<p>T H A N K Y O U !</p>
					<p>Your session time was&nbsp;<?php echo gmdate("H:i:s", $duration); ?>&nbsp; (HH:MM:SS) !</p>
				</div><!-- end --><!-- class="wrap" -->
			</div>

		 	<div class="bottom-grids">
				<div class="wrap">
					<?php	require_once('./includes/latest.php');	?>
					<?php	require_once('./includes/featured.php');		?>
				</div> <!-- end --><!-- class="wrap" -->
				<div class="clear"> </div>
			</div>
			
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>