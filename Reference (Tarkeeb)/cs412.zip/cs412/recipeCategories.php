<?php
	require_once ('includes/classes/category.php');
	require_once ('includes/classes/recipe.php');
	
	if ( !isset($_GET['categoryId']) ) { $categoryId = 0; } else { $categoryId = $_GET['categoryId']; }
?>
							
<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		 <div class="content">
		 	<div class="bottom-grids">
				<div class="wrap">
					<div class="bottom-grid1">
						<h3><a href="recipeCategories.php" style="color:inherit;">Categories</a></h3>
						<ul>
							<?php
								$results = Category::getCategories(1);
								if (count($results) > 0){
									foreach($results as $row) {
									   echo '<li><a href="?categoryId='. $row['id']. '"><span>'.$row['name'].'</span></a></li>';
									}
								}
								else{
									echo '<li><a><span>'.'No Categories!'.'</span></a></li>';
								}
							?>
						</ul>
					</div> <!-- end bottom-grid1 -->

					<div class="bottom-grid2 bottom-mid grid-recipes">
						<h3>Displaying&nbsp;
						<?php
							if ( !isset($_GET['categoryId']) ) { echo "All Categories"; } else {
								$category = Category::getCategoryById($_GET['categoryId']);
								if ($category!=null){
									echo "Category: ". $category->name;
								}
							}
						?>
						</h3>
						<?php
							if ($categoryId!=0) echo '<a class="button" href="./recipeCategories.php" style="float:right;">View All Categories</a>';
						?>
						<?php							
							$results = Recipe::getRecipeByCategory($categoryId);
							if (count($results) > 0){
								echo "<p><strong>There are ".count($results)." recipes posted in this category</strong></p>";
								echo '<div class="gallery">';
								echo '<ul>';
								foreach($results as $row) {
								   echo '<li><h2>'.$row['title'].'</h2>';
								   echo '<a href="recipePage.php?recipeId='.$row['id'].'">';
								   echo '<img src="'.$row['image1']. '" title="'.$row['title'].'" /></a></li>';
								}
								echo '<div class="clear"> </div>';
								echo '</ul>';									
								echo '</div>';									
							}
							else
								echo "<p><strong>There are no recipes posted in this category</strong></p>";
							
						?>

					</div> <!-- end bottom-grid2 bottom-mid-->						
					
					<div class="clear"> </div>
				</div><!-- end --><!-- class="wrap" -->		
			</div>
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>