<?php
	require_once ('includes/classes/recipe.php');
	require_once ('includes/classes/user.php');
?>

<?php
	if (isset($_GET['recipeId'])){
		$recipeId = $_GET['recipeId'];
		$recipe = Recipe::getRecipeById($recipeId);
		
		if ($recipe == null)
		header( 'Location: error.php?errorMsg=' . urlencode("No Recipe found!") );
	}
	else
		header( 'Location: error.php?errorMsg=' . urlencode("No Landing page!") );

?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
		 	<div class="about-us">
				<div class="wrap">
					<?php
						if(!isset($_SESSION)) session_start();
						$user = null;
						if ( isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true )
						$user = User::getUserByUserName($_SESSION['username']);
						if ( ($user!=null && $recipe->userId==$user->id) || ($user!=null && $user->type == "admin") )
						echo '<a class="button" href="addEditRecipe.php?recipeId='.$recipe->id.'">Edit this recipe</a><br /><br />';
						
					?>
						
					<div class="about-header">
						<h3><?php echo $recipe->title; ?></h3>
						<div class="clear"> </div>
					</div>
					<div class="about-info">
						<a><?php echo $recipe->subtitle; ?></a>
					</div>						
					<div class="specials-grids">
						<div class="imagesS-grid">
							<img src="<?php echo $recipe->image1; ?>" alt="<?php echo $recipe->imagealt1; ?>">
						</div>
						<div class="imagesS-grid">
							<img src="<?php echo $recipe->image2; ?>" alt="<?php echo $recipe->imagealt2; ?>">
						</div>
						<div class="imagesS-grid spe-grid">
							<img src="<?php echo $recipe->image3; ?>" alt="<?php echo $recipe->imagealt3; ?>">
						</div>
					</div>
					
					<div class="clear"> </div> <br />
					
					<div class="about-info">
						<p><?php echo nl2br($recipe->recipe); ?></p>
					</div>
				</div><!-- end --><!-- class="wrap" -->			
			</div>
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>