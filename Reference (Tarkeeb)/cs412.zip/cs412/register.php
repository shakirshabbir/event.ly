<?php	require_once ('./includes/classes/user.php');	?>
<?php
	$createSuccess = false;
	if ( isset($_POST['registerSumbit']) )
	{
		$username = $_POST['userName'];
		$password = $_POST['password'];
		$email = $_POST['email'];		
		
		$user = new User($username, $password);
		$user->createNewUser($username, $password, $email, $newUser);
		
		if ($newUser!=null)
		$createSuccess = true;
	}
?>


<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
			<?php
				if($createSuccess) {
					echo '<div class="wrap"><div class="about-info"><a>New user created successfully.<a href="login.php"> Please login!</a></a></div></div>';
				}
			?>
		 	<div class="bottom-grids">
				<div class="wrap">
					<div class="form">
					<form name="registerForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">							
						<span><label>Username</label></span>
						<input name="userName" type="text" class="textbox" required="required" />

						<span><label>Email</label></span>
						<input name="email" type="email" class="textbox" required="required" />

						<span><label>Password</label></span>
						<input name="password" type="password" required="required" style="width:98%;"/>
						<div class="clear"> </div>					

						<span><input name="registerSumbit" type="submit" class="mybutton" value="Submit" /></span>					
							
					</form>
					</div><!-- end --><!-- class="form" -->
				</div><!-- end --><!-- class="wrap" -->
			</div>
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>