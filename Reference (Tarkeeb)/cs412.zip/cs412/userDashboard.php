<?php
	require_once ('includes/classes/recipe.php');
	require_once ('includes/classes/user.php');
?>

<?php
	if(!isset($_SESSION)) session_start();
	$user = User::getUserByUserName($_SESSION['username']);
	if ($user!=null) {
		$results = Recipe::getRecipesByUserId($user->id);
	}
	else
		header( 'Location: error.php?errorMsg=' . urlencode("You tried to enter a restricted area!") );
?>

<!DOCTYPE HTML>
<html>
	<head>
		<?php	require_once ('./includes/head_info.php');	?>
	</head>
	<body>
		<!-- Header -->
		<div class="header">	
			<!-- Login/Register Buttons -->
			<?php	require_once('./includes/userInfo.php');	?>
			<!-- end --><!-- Login/Register Buttons -->
			
			<div class="wrap">
				<?php	require_once('./includes/top_header.php');	?>
				<?php 	require_once('./includes/top_nav.php');	?>
			</div>
		</div>
		<!-- end --><!-- Header -->
		 
		<!-- Content -->
		<div class="content">
			<div class="wrap">
				<a href="logout.php" class="button" style="float:right;">Logout</a>
			</div>

		 	<div class="bottom-grids">
				<div class="wrap">
					<div class="bottom-grid1">
						<h3>My Recipes</h3>
						<?php
							if (count($results) > 0){
								echo '<ul>';
								foreach($results as $row) {
								   echo '<li>';
								   echo '<a href="recipePage.php?recipeId='.$row['id'].'">'. $row['title'];
								   echo '</a></li>';
								}							
								echo '</ul>';
							}
							else
								echo "You have not posted any recipe!";
						?>							
						<a class="button" href="addEditRecipe.php">Add a new recipe</a>
					</div>
					<div class="clear"> </div>
				</div><!-- end --><!-- class="wrap" -->
			</div>
		</div>
		<!-- end --><!-- Content -->

		<!-- Footer -->
			<?php	require_once('./includes/footer.php');	?>
		<!-- end --><!-- Footer -->
	</body>
</html>